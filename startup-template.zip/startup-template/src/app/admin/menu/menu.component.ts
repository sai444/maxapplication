import { Component, ViewEncapsulation, ChangeDetectionStrategy, OnInit, AfterViewInit } from '@angular/core';
import { Observable } from 'rxjs';
import { Store, select } from '@ngrx/store';
import { MenuModel, MenuHeaderModel, MenuUserModel, MenuService } from '@addapptables/menu';
import { AddapptableState } from 'src/app/reducres';
import { LoadMenus } from 'src/app/@redux/menu/actions/menu.actions';
import { selectAllMenus } from 'src/app/@redux/menu/selectors/menu.selector';

@Component({
    selector: 'app-menu',
    templateUrl: './menu.component.html',
    styleUrls: ['./menu.component.scss'],
    encapsulation: ViewEncapsulation.None,
    changeDetection: ChangeDetectionStrategy.OnPush
})
export class MenuComponent implements OnInit, AfterViewInit {

    menus$: Observable<MenuModel[]>;

    header: MenuHeaderModel = {
        companyName: 'ADDAPPTABLES',
        logoUrl: 'assets/images/logo/addaptables.svg'
    };

    user: MenuUserModel = {
        initialName: 'MG',
        fullName: 'Mateo Guerra',
        email: 'dev@addapptables.com',
        avatarUrl: 'assets/images/avatars/Velazquez.jpg'
    };

    constructor(private readonly _store: Store<AddapptableState>, private _menuService: MenuService) {
        _store.dispatch(new LoadMenus());
    }

    ngOnInit() {
        this.menus$ = this._store.pipe(
            select(selectAllMenus),
        );
    }

    ngAfterViewInit() {
        this._menuService.open$.subscribe(console.log);
    }
}
