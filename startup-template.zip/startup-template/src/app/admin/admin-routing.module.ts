import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { LayoutComponent } from './layout/layout.component';

const routes: Routes = [{
    path: '',
    component: LayoutComponent,
    children: [
        {
            path: '',
            redirectTo: 'users',
            pathMatch: 'full'
        },
        {
            path: 'users',
            loadChildren: 'src/app/admin/user/user.module#UserModule',
            data: { permission: 'Pages.Administration.Users' }
        },
    ]
}];

@NgModule({
    imports: [RouterModule.forChild(routes)],
    exports: [RouterModule]
})
export class AdminRoutingModule { }
