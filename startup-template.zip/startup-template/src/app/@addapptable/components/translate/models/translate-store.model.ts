import { LanguageModel } from './language.model';

export class TranslateStoreModel {
    loading: boolean;
    languages: LanguageModel[];
}
