export interface LanguageModel {
    id: string;
    title: string;
    country: string;
}
