import { MenuModel } from '@addapptables/menu';

export interface MenuStoreModel {
    menus: MenuModel[];
    loading: boolean;
}
