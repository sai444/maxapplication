import { MenuModel } from '@addapptables/menu';

export const menus: MenuModel[] = [
    {
        id: '1',
        class: 'material-icons',
        value: 'people',
        title: 'user.title',
        isOpen: false,
        multiOption: false,
        url: '/admin/users',
        exact: true
    }
];
